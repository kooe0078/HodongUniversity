#include "MainScene.h"
#include "EndScene.h"
#include "SimpleAudioEngine.h"

//���� �Ҷ�� �� �ʿ�
using namespace CocosDenshion;
USING_NS_CC;

Scene* MainScene::createScene()
{
    auto scene = Scene::create();
    auto layer = MainScene::create();
    scene->addChild(layer);

    return scene;
}

bool MainScene::init()
{

    if ( !Layer::init() )
    {
        return false;
    }

	visibleSize = Director::getInstance()->getVisibleSize();
	origin      = Director::getInstance()->getVisibleOrigin();

	InitBackGround();
	InitSprite();
	InitLabel();
	
	//Vector �ڼ��� ������ http://quse.kr/category/Cocos2D-X �����ϻ�
	mpData = cocos2d::Vector<cocos2d::Sprite*>(100);

	//�������
	SimpleAudioEngine::getInstance()->playBackgroundMusic("MiniGameResources/MainBackSound.mp3", true);
	//������
	this->schedule(schedule_selector(MainScene::update));
	this->schedule(schedule_selector(MainScene::SetBlock), 0.25f);
	this->schedule(schedule_selector(MainScene::SetLabel), 1.0f);
	//Ű���� ������
	auto keylistener = EventListenerKeyboard::create();
	keylistener->onKeyPressed = CC_CALLBACK_2(MainScene::onKeyPressed, this);
	keylistener->onKeyReleased = CC_CALLBACK_2(MainScene::onKeyReleased, this);
	_eventDispatcher->addEventListenerWithSceneGraphPriority(keylistener, this);

    return true;
}
void MainScene::update(float ft)
{
	//�� ��ü������ �ݺ� �Ǿ��ϴ� ����
	Sprite* chickSpr = (Sprite *)this->getChildByTag(1);
	for (Sprite* blockSpr : mpData)
	{
		Rect rectChik = Rect(chickSpr->getPositionX() + 5, chickSpr->getPositionY(),
			10, chickSpr->getContentSize().height - 10);
		Rect rectBlock = blockSpr->getBoundingBox();

		if (rectChik.intersectsRect(rectBlock)) 
		{
			Sprite* effect = Sprite::create("MiniGameResources/hitEffect.png");
			effect->setAnchorPoint(Point(0.5, 0));
			effect->setPosition(Point(chickSpr->getPositionX() + 10, chickSpr->getPositionY() + 5));
			this->addChild(effect);

			SimpleAudioEngine::getInstance()->playEffect("MiniGameResources/Hit.wav");

			Director::getInstance()->getEventDispatcher()->removeAllEventListeners();
			Director::getInstance()->replaceScene(EndScene::createScene());
		}
	}
}

void MainScene::InitBackGround()
{
	auto sprite = Sprite::create("MiniGameResources/MainBackGround.jpg");
	sprite->setPosition(Point(visibleSize.width / 2 + origin.x, visibleSize.height / 2 + origin.y));
	this->addChild(sprite, 0);
}
void MainScene::InitSprite()
{
	Sprite* chickSpr = Sprite::create("MiniGameResources/player_fly_f01.png");
	chickSpr->setAnchorPoint(Point(0.5, 0));
	chickSpr->setPosition(Point(120, 100));
	chickSpr->setTag(1);
	this->addChild(chickSpr);

	Animation* ani = Animation::create();
	ani->setDelayPerUnit(0.3);

	for (int i = 0; i < 3; i++) {
		ani->addSpriteFrameWithFile(StringUtils::format("MiniGameResources/player_fly_f%02d.png", i + 1));
	}
	ani->addSpriteFrameWithFile("MiniGameResources/player_fly_f02.png");

	Animate*		anim = Animate::create(ani);
	RepeatForever*	action = RepeatForever::create(anim);
	chickSpr->runAction(action);
}
void MainScene::InitLabel()
{
	Label* label = Label::createWithTTF(StringUtils::format("PlayTime : %d", 0), "MiniGameResources/CuteFont.ttf", 30);
	label->setAnchorPoint(Point(0, 1));
	label->setPosition(Point(20, 520));
	label->setColor(Color3B::BLACK);
	label->setTag(5);
	this->addChild(label,2);
}
void MainScene::SetBlock(float delta)
{
	Sprite* spr = Sprite::create("MiniGameResources/scene_01_blockDown.png");
	spr->setAnchorPoint(Point(0.5, 0));
	spr->setPosition(Point(rand() % 80 * 10, 600));
	mpData.pushBack(spr);
	this->addChild(spr);

	MoveBy*		action1 = MoveBy::create(5.5, Point(0, -1200));
	Sequence*	action2 = Sequence::create(action1, RemoveSelf::create(), NULL);
	spr->runAction(action2);
}
void MainScene::SetLabel(float delta)
{
	static int currClock = 0;
	currClock += 1;

	Label* label = (Label*)this->getChildByTag(5);
	label->setString(StringUtils::format("PlayTime : %d", currClock));
}

void MainScene::onKeyPressed(EventKeyboard::KeyCode keyCode, Event* event)
{
	//�̷� ������ Ű ���� ���� ó���� �ϸ� �ȴ�
	auto spr = (Sprite*)this->getChildByTag(1);
	switch (keyCode)
	{
	case EventKeyboard::KeyCode::KEY_LEFT_ARROW:
	{
		spr->setRotationY(180);
		auto action_0 = MoveBy::create(1, Point(-150, 0));
		auto action_1 = RepeatForever::create(action_0);
		action_1->setTag(3);
		spr->runAction(action_1);
		break;
	}
	case EventKeyboard::KeyCode::KEY_RIGHT_ARROW:
	{
		spr->setRotationY(0);
		auto action_2 = MoveBy::create(1, Point(150, 0));
		auto action_3 = RepeatForever::create(action_2);
		action_3->setTag(4);
		spr->runAction(action_3);
		break;
	}
	}
}
void MainScene::onKeyReleased(EventKeyboard::KeyCode keyCode, Event* event)
{
	auto spr = (Sprite*)this->getChildByTag(1);
	switch (keyCode)
	{
	case EventKeyboard::KeyCode::KEY_LEFT_ARROW:
		spr->stopActionByTag(3);
		break;
	case EventKeyboard::KeyCode::KEY_RIGHT_ARROW:
		spr->stopActionByTag(4);
		break;
	}
}